<?php

namespace App\Models\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Support\Facades\Auth;

class TenantScope implements Scope
{
    /**
     * Apply the scope to a given Eloquent query builder.
     */
    public function apply(Builder $builder, Model $model): void
    {
        if (app()->runningInConsole() && !app()->runningUnitTests()) {
            return;
        }

        $tenantId = static::getTenantId();

        if ($tenantId !== null) {
            $builder->where($model->getTable() . '.organization_id', '=', $tenantId);
        }
    }

    /**
     * Get the active organization ID from session, header, or authenticated user.
     */
    public static function getTenantId(): ?int
    {
        if (session()->has('organization_id')) {
            return (int) session('organization_id');
        }

        if (request()->hasHeader('X-Organization-ID')) {
            return (int) request()->header('X-Organization-ID');
        }

        $user = Auth::user();
        if ($user && isset($user->organization_id)) {
            return (int) $user->organization_id;
        }

        return null;
    }
}
